﻿using Oracle.DataAccess.Client;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Court_System.Defendant
{
    public partial class D_CaseForm : Form
    {
        string Case_id = "";
        private List<File_> filees;
        OracleDataAdapter adapter = null;
        DataSet ds = null;
        string lawyer_id = "";
        public D_CaseForm(string Case_id)
        {
            this.StartPosition = FormStartPosition.CenterScreen;

            InitializeComponent();
            this.Case_id = Case_id;
            filees = new List<File_>();
        }

        private void D_CaseForm_Load(object sender, EventArgs e)
        {

            string comd = "select * from cases where CASE_ID=" + Case_id;
            adapter = new OracleDataAdapter(comd, Program.conn);
            ds = new DataSet();
            adapter.Fill(ds);

            description.Text = ds.Tables[0].Rows[0]["DESCRIPTION"].ToString();
            decision.Text = ds.Tables[0].Rows[0]["DECISION"].ToString();
            defendant.Text = ds.Tables[0].Rows[0]["DEFENDANT_ID"].ToString();
            status.Text = ds.Tables[0].Rows[0]["STATUS"].ToString();
            requestDate.Text = ds.Tables[0].Rows[0]["REQUEST_DATE"].ToString();
            startDate.Text = ds.Tables[0].Rows[0]["START_DATE"].ToString();
            caseDate.Text = ds.Tables[0].Rows[0]["CASE_DATE"].ToString();
            endDate.Text = ds.Tables[0].Rows[0]["END_DATE"].ToString();
            place.Text = ds.Tables[0].Rows[0]["PLACE"].ToString();
            lawyer_id = ds.Tables[0].Rows[0]["LAWYER_ID"].ToString();
            lawyer.Text = User.User.get_user_name(lawyer_id);
            defendant.Text = User.User.get_user_name(ds.Tables[0].Rows[0]["DEFENDANT_ID"].ToString());
            if (lawyer_id == "") {
                assign.Enabled = true;
            }
            OracleCommand cmd1 = new OracleCommand();
            cmd1.Connection = Program.conn;
            cmd1.CommandType = CommandType.Text;
            cmd1.CommandText = "select FILENAME from CASE_DOCUMENTS where CASE_ID = " + Case_id;
            OracleDataReader dr = cmd1.ExecuteReader();
            while (dr.Read())
            {

                docComboBox.Items.Add(dr[0]);
            }
            cmd1.CommandText = "select JUDGE_ID from CASE_JUDGES where CASE_ID = " + Case_id;
            dr = cmd1.ExecuteReader();
            while (dr.Read())
            {
                judgesList.Items.Add(User.User.get_user_name(dr[0].ToString()));
            }
            OracleCommand cmd = new OracleCommand();
            cmd.Connection = Program.conn;
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select user_id from users where user_type = :lawyer";
            cmd.Parameters.Add("lawyer", "lawyer");
            OracleDataReader dr0 = cmd.ExecuteReader();
            while (dr0.Read())
            {
                allLawyers.Items.Add(dr0[0]);
            }


        }

        private void button4_Click(object sender, EventArgs e)
        {
            //save
            if (lawyer_id != "") {
                assign.Enabled = false;
            }
            ds.Tables[0].Rows[0]["LAWYER_ID"] = lawyer_id;
            lawyer.Text = User.User.get_user_name(lawyer_id);
            OracleCommandBuilder oracleCommandBuilder = new OracleCommandBuilder(adapter);
            adapter.Update(ds.Tables[0]);
            int sizefiles = filees.Count;
            foreach (File_ f in filees)
            {
                OracleCommand cmd1 = new OracleCommand();
                cmd1.Connection = Program.conn;
                cmd1.CommandType = CommandType.Text;
                cmd1.CommandText = "insert into CASE_DOCUMENTS values(:CASE_ID,:FILENAME,:FILEDATA)";
                cmd1.Parameters.Add("CASE_ID", Case_id);
                cmd1.Parameters.Add("FILENAME", f.name);
                cmd1.Parameters.Add("FILEDATA", f.fileContent);
                try
                {
                    cmd1.ExecuteNonQuery();
                    sizefiles--;
                }
                catch (Exception e00)
                {
                    MessageBox.Show("Error \n" + e00.Message.ToString());
                }
            }
            if (sizefiles == 0)
            {
                MessageBox.Show("Done");
            }
        }

        private void button12_Click(object sender, EventArgs e)
        {
            //open pdf

            string fileName = Convert.ToString(docComboBox.Text.ToString());
            if (fileName == "") return;
            OracleCommand cmd1 = new OracleCommand();
            cmd1.Connection = Program.conn;
            cmd1.CommandText = "select FILEDATA from CASE_DOCUMENTS where FILENAME = :fileName";
            cmd1.Parameters.Add("fileName", fileName);
            OracleDataReader reader = cmd1.ExecuteReader();
            if (!reader.Read())
            {
                MessageBox.Show("Click save first");
                return;
            }
            byte[] buffer = new byte[reader.GetBytes(0, 0, null, 0, int.MaxValue)];
            reader.GetBytes(0, 0, buffer, 0, buffer.Length);
            try
            {
                SaveFileDialog saveFileDialog = new SaveFileDialog();
                saveFileDialog.Filter = "|*.pdf";
                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string filePath = saveFileDialog.FileName;
                    File.WriteAllBytes(filePath, buffer);
                    Process.Start(filePath);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void button11_Click(object sender, EventArgs e)
        {
            //add pdf
            OracleCommand loCmd = Program.conn.CreateCommand();
            loCmd.CommandType = CommandType.Text;
            loCmd.CommandText = "select DOCUMENT_ID_SEQ.nextval from dual";
            string document_id = Convert.ToString(loCmd.ExecuteScalar());
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            openFileDialog1.Filter = "|*.pdf";
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                string filePath = openFileDialog1.FileName;
                byte[] fileContent = File.ReadAllBytes(filePath);
                string fileName = document_id + "_" + Path.GetFileName(filePath);
                docComboBox.Items.Add(fileName);
                filees.Add(new File_(fileName, fileContent));
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Assign a lawyer
            lawyer_id = allLawyers.Text.ToString();


        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            new D_Home().Show();
            this.Close();
        }

        private void allLawyers_SelectedIndexChanged(object sender, EventArgs e)
        {
            newLawyer.Text = User.User.get_user_name(allLawyers.Text.ToString());
        }
    }
}
