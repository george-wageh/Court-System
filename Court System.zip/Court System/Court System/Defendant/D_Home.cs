﻿using Court_System.Lawyer;
using Oracle.DataAccess.Client;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Court_System.Defendant
{
    public partial class D_Home : Form
    {
        public D_Home()
        {
            this.StartPosition = FormStartPosition.CenterScreen;

            InitializeComponent();
        }

        private string getStatus()
        {

            if (newR.Checked)
            {
                return "new";
            }
            else if (opendR.Checked)
            {
                return "opened";
            }
            else if (closedR.Checked)
            {
                return "closed";
            }
            else if (adjournR.Checked)
            {
                return "adjournment";
            }
            else if (appealR.Checked)
            {
                return "appeal";
            }
            else return "";
        }
        OracleDataAdapter adapter =null;
        private void fillDataGrid() {

            string comd = "select CASE_ID,DESCRIPTION,REQUEST_DATE,START_DATE,CASE_DATE,PLACE from cases where DEFENDANT_ID = :userId and STATUS = :status";
            OracleCommand oracleCommand = new OracleCommand(comd);
            oracleCommand.Parameters.Add("userId", Program.user.Id);
            oracleCommand.Parameters.Add("status", getStatus());
            oracleCommand.Connection = Program.conn;
            adapter = new OracleDataAdapter(oracleCommand);
            DataSet ds = new DataSet();
            adapter.Fill(ds);
            casesDataGrid.DataSource = ds.Tables[0];
            numberCases.Text = User.User.get_numberCases(Program.user.Id);

        }
        private void D_Home_Load(object sender, EventArgs e)
        {
            fillDataGrid();


            Rectangle screen = Screen.PrimaryScreen.WorkingArea;
            int x = (screen.Width - this.Width) / 2;
            int y = (screen.Height - this.Height) / 2;
            this.Location = new Point(x, y);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Program.user = null;
            new Court_System.User.LoginForm().Show();
            this.Close();
        }

        private void casesDataGrid_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.RowIndex < casesDataGrid.Rows.Count) {

                string CASE_ID = casesDataGrid.Rows[e.RowIndex].Cells[0].Value.ToString();
                new D_CaseForm(CASE_ID).Show();
                this.Close();

            }

        }

        private void closedR_CheckedChanged(object sender, EventArgs e)
        {
            fillDataGrid();

        }
    }
}
