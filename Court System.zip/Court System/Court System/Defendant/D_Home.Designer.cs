﻿namespace Court_System.Defendant
{
    partial class D_Home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.casesDataGrid = new System.Windows.Forms.DataGridView();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.closedR = new System.Windows.Forms.RadioButton();
            this.appealR = new System.Windows.Forms.RadioButton();
            this.newR = new System.Windows.Forms.RadioButton();
            this.adjournR = new System.Windows.Forms.RadioButton();
            this.opendR = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.numberCases = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.casesDataGrid)).BeginInit();
            this.SuspendLayout();
            // 
            // casesDataGrid
            // 
            this.casesDataGrid.AllowUserToAddRows = false;
            this.casesDataGrid.AllowUserToDeleteRows = false;
            this.casesDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.casesDataGrid.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.casesDataGrid.Location = new System.Drawing.Point(114, 100);
            this.casesDataGrid.Name = "casesDataGrid";
            this.casesDataGrid.Size = new System.Drawing.Size(582, 194);
            this.casesDataGrid.TabIndex = 11;
            this.casesDataGrid.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.casesDataGrid_CellDoubleClick);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(12, 59);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 60;
            this.button2.Text = "Exit";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(12, 12);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 59;
            this.button3.Text = "Back";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // closedR
            // 
            this.closedR.AutoSize = true;
            this.closedR.Location = new System.Drawing.Point(246, 40);
            this.closedR.Name = "closedR";
            this.closedR.Size = new System.Drawing.Size(57, 17);
            this.closedR.TabIndex = 68;
            this.closedR.Text = "Closed";
            this.closedR.UseVisualStyleBackColor = true;
            this.closedR.CheckedChanged += new System.EventHandler(this.closedR_CheckedChanged);
            // 
            // appealR
            // 
            this.appealR.AutoSize = true;
            this.appealR.Location = new System.Drawing.Point(448, 40);
            this.appealR.Name = "appealR";
            this.appealR.Size = new System.Drawing.Size(101, 17);
            this.appealR.TabIndex = 67;
            this.appealR.Text = "Appeal requests";
            this.appealR.UseVisualStyleBackColor = true;
            this.appealR.CheckedChanged += new System.EventHandler(this.closedR_CheckedChanged);
            // 
            // newR
            // 
            this.newR.AutoSize = true;
            this.newR.Checked = true;
            this.newR.Location = new System.Drawing.Point(114, 40);
            this.newR.Name = "newR";
            this.newR.Size = new System.Drawing.Size(47, 17);
            this.newR.TabIndex = 66;
            this.newR.TabStop = true;
            this.newR.Text = "New";
            this.newR.UseVisualStyleBackColor = true;
            this.newR.CheckedChanged += new System.EventHandler(this.closedR_CheckedChanged);
            // 
            // adjournR
            // 
            this.adjournR.AutoSize = true;
            this.adjournR.Location = new System.Drawing.Point(315, 40);
            this.adjournR.Name = "adjournR";
            this.adjournR.Size = new System.Drawing.Size(127, 17);
            this.adjournR.TabIndex = 65;
            this.adjournR.Text = "Adjournment requests";
            this.adjournR.UseVisualStyleBackColor = true;
            this.adjournR.CheckedChanged += new System.EventHandler(this.closedR_CheckedChanged);
            // 
            // opendR
            // 
            this.opendR.AutoSize = true;
            this.opendR.Location = new System.Drawing.Point(177, 40);
            this.opendR.Name = "opendR";
            this.opendR.Size = new System.Drawing.Size(63, 17);
            this.opendR.TabIndex = 64;
            this.opendR.Text = "Opened";
            this.opendR.UseVisualStyleBackColor = true;
            this.opendR.CheckedChanged += new System.EventHandler(this.closedR_CheckedChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(118, 77);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(87, 13);
            this.label1.TabIndex = 69;
            this.label1.Text = "Number of cases";
            // 
            // numberCases
            // 
            this.numberCases.Location = new System.Drawing.Point(212, 75);
            this.numberCases.Name = "numberCases";
            this.numberCases.ReadOnly = true;
            this.numberCases.Size = new System.Drawing.Size(100, 20);
            this.numberCases.TabIndex = 70;
            // 
            // D_Home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.ControlBox = false;
            this.Controls.Add(this.numberCases);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.closedR);
            this.Controls.Add(this.appealR);
            this.Controls.Add(this.newR);
            this.Controls.Add(this.adjournR);
            this.Controls.Add(this.opendR);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.casesDataGrid);
            this.Name = "D_Home";
            this.Text = "Defendant home";
            this.Load += new System.EventHandler(this.D_Home_Load);
            ((System.ComponentModel.ISupportInitialize)(this.casesDataGrid)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.DataGridView casesDataGrid;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.RadioButton closedR;
        private System.Windows.Forms.RadioButton appealR;
        private System.Windows.Forms.RadioButton newR;
        private System.Windows.Forms.RadioButton adjournR;
        private System.Windows.Forms.RadioButton opendR;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox numberCases;
    }
}