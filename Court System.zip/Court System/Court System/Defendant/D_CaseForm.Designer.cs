﻿namespace Court_System.Defendant
{
    partial class D_CaseForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label10 = new System.Windows.Forms.Label();
            this.newLawyer = new System.Windows.Forms.TextBox();
            this.assign = new System.Windows.Forms.Button();
            this.allLawyers = new System.Windows.Forms.ComboBox();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.docComboBox = new System.Windows.Forms.ComboBox();
            this.label16 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.decision = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.endDate = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.caseDate = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.startDate = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.requestDate = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.status = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.description = new System.Windows.Forms.TextBox();
            this.place = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lawyer = new System.Windows.Forms.TextBox();
            this.judgesList = new System.Windows.Forms.ListBox();
            this.judges = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.defendant = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(631, 246);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(35, 13);
            this.label10.TabIndex = 113;
            this.label10.Text = "Name";
            // 
            // newLawyer
            // 
            this.newLawyer.Location = new System.Drawing.Point(672, 244);
            this.newLawyer.Name = "newLawyer";
            this.newLawyer.ReadOnly = true;
            this.newLawyer.Size = new System.Drawing.Size(91, 20);
            this.newLawyer.TabIndex = 112;
            // 
            // assign
            // 
            this.assign.Enabled = false;
            this.assign.Location = new System.Drawing.Point(656, 277);
            this.assign.Name = "assign";
            this.assign.Size = new System.Drawing.Size(88, 34);
            this.assign.TabIndex = 93;
            this.assign.Text = "Assign a lawyer";
            this.assign.UseVisualStyleBackColor = true;
            this.assign.Click += new System.EventHandler(this.button1_Click);
            // 
            // allLawyers
            // 
            this.allLawyers.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.allLawyers.FormattingEnabled = true;
            this.allLawyers.Location = new System.Drawing.Point(631, 209);
            this.allLawyers.Name = "allLawyers";
            this.allLawyers.Size = new System.Drawing.Size(132, 21);
            this.allLawyers.TabIndex = 111;
            this.allLawyers.SelectedIndexChanged += new System.EventHandler(this.allLawyers_SelectedIndexChanged);
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(380, 297);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(106, 23);
            this.button11.TabIndex = 162;
            this.button11.Text = "Insert pdf";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(281, 297);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(81, 23);
            this.button12.TabIndex = 161;
            this.button12.Text = "Open pdf";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // docComboBox
            // 
            this.docComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.docComboBox.FormattingEnabled = true;
            this.docComboBox.Location = new System.Drawing.Point(158, 297);
            this.docComboBox.Name = "docComboBox";
            this.docComboBox.Size = new System.Drawing.Size(103, 21);
            this.docComboBox.TabIndex = 159;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(141, 272);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(60, 13);
            this.label16.TabIndex = 154;
            this.label16.Text = "Legal Files:";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(12, 59);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 206;
            this.button2.Text = "Exit";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(12, 12);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 205;
            this.button3.Text = "Back";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(344, 363);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 209;
            this.button4.Text = "Save";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // decision
            // 
            this.decision.Location = new System.Drawing.Point(147, 164);
            this.decision.Multiline = true;
            this.decision.Name = "decision";
            this.decision.ReadOnly = true;
            this.decision.Size = new System.Drawing.Size(100, 68);
            this.decision.TabIndex = 232;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(130, 137);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(75, 13);
            this.label4.TabIndex = 231;
            this.label4.Text = "Case Decision";
            // 
            // endDate
            // 
            this.endDate.ForeColor = System.Drawing.Color.Black;
            this.endDate.Location = new System.Drawing.Point(490, 110);
            this.endDate.Name = "endDate";
            this.endDate.ReadOnly = true;
            this.endDate.Size = new System.Drawing.Size(100, 20);
            this.endDate.TabIndex = 230;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(470, 84);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 13);
            this.label3.TabIndex = 229;
            this.label3.Text = "End Date:";
            // 
            // caseDate
            // 
            this.caseDate.ForeColor = System.Drawing.Color.Black;
            this.caseDate.Location = new System.Drawing.Point(490, 45);
            this.caseDate.Name = "caseDate";
            this.caseDate.ReadOnly = true;
            this.caseDate.Size = new System.Drawing.Size(100, 20);
            this.caseDate.TabIndex = 228;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(305, 148);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(76, 13);
            this.label2.TabIndex = 227;
            this.label2.Text = "Request Date:";
            // 
            // startDate
            // 
            this.startDate.ForeColor = System.Drawing.Color.Black;
            this.startDate.Location = new System.Drawing.Point(320, 237);
            this.startDate.Name = "startDate";
            this.startDate.ReadOnly = true;
            this.startDate.Size = new System.Drawing.Size(100, 20);
            this.startDate.TabIndex = 226;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.ForeColor = System.Drawing.Color.Black;
            this.label17.Location = new System.Drawing.Point(472, 23);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(60, 13);
            this.label17.TabIndex = 225;
            this.label17.Text = "Case Date:";
            // 
            // requestDate
            // 
            this.requestDate.ForeColor = System.Drawing.Color.Black;
            this.requestDate.Location = new System.Drawing.Point(320, 174);
            this.requestDate.Name = "requestDate";
            this.requestDate.ReadOnly = true;
            this.requestDate.Size = new System.Drawing.Size(100, 20);
            this.requestDate.TabIndex = 224;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.ForeColor = System.Drawing.Color.Black;
            this.label18.Location = new System.Drawing.Point(302, 210);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(58, 13);
            this.label18.TabIndex = 223;
            this.label18.Text = "Start Date:";
            // 
            // status
            // 
            this.status.ForeColor = System.Drawing.Color.Black;
            this.status.Location = new System.Drawing.Point(320, 110);
            this.status.Name = "status";
            this.status.ReadOnly = true;
            this.status.Size = new System.Drawing.Size(100, 20);
            this.status.TabIndex = 222;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.ForeColor = System.Drawing.Color.Black;
            this.label15.Location = new System.Drawing.Point(300, 84);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(40, 13);
            this.label15.TabIndex = 221;
            this.label15.Text = "Status:";
            // 
            // description
            // 
            this.description.ForeColor = System.Drawing.Color.Black;
            this.description.Location = new System.Drawing.Point(144, 47);
            this.description.Multiline = true;
            this.description.Name = "description";
            this.description.ReadOnly = true;
            this.description.Size = new System.Drawing.Size(100, 68);
            this.description.TabIndex = 220;
            // 
            // place
            // 
            this.place.ForeColor = System.Drawing.Color.Black;
            this.place.Location = new System.Drawing.Point(490, 174);
            this.place.Name = "place";
            this.place.ReadOnly = true;
            this.place.Size = new System.Drawing.Size(100, 20);
            this.place.TabIndex = 219;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(470, 148);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(37, 13);
            this.label1.TabIndex = 218;
            this.label1.Text = "Place:";
            // 
            // lawyer
            // 
            this.lawyer.ForeColor = System.Drawing.Color.Black;
            this.lawyer.Location = new System.Drawing.Point(490, 237);
            this.lawyer.Name = "lawyer";
            this.lawyer.ReadOnly = true;
            this.lawyer.Size = new System.Drawing.Size(100, 20);
            this.lawyer.TabIndex = 217;
            // 
            // judgesList
            // 
            this.judgesList.ForeColor = System.Drawing.Color.Black;
            this.judgesList.FormattingEnabled = true;
            this.judgesList.Location = new System.Drawing.Point(633, 45);
            this.judgesList.Name = "judgesList";
            this.judgesList.Size = new System.Drawing.Size(100, 82);
            this.judgesList.TabIndex = 216;
            // 
            // judges
            // 
            this.judges.AutoSize = true;
            this.judges.ForeColor = System.Drawing.Color.Black;
            this.judges.Location = new System.Drawing.Point(615, 20);
            this.judges.Name = "judges";
            this.judges.Size = new System.Drawing.Size(44, 13);
            this.judges.TabIndex = 215;
            this.judges.Text = "Judges:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.ForeColor = System.Drawing.Color.Black;
            this.label13.Location = new System.Drawing.Point(470, 210);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(44, 13);
            this.label13.TabIndex = 214;
            this.label13.Text = "Lawyer:";
            // 
            // defendant
            // 
            this.defendant.ForeColor = System.Drawing.Color.Black;
            this.defendant.Location = new System.Drawing.Point(320, 45);
            this.defendant.Name = "defendant";
            this.defendant.ReadOnly = true;
            this.defendant.Size = new System.Drawing.Size(100, 20);
            this.defendant.TabIndex = 213;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.ForeColor = System.Drawing.Color.Black;
            this.label14.Location = new System.Drawing.Point(300, 19);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(60, 13);
            this.label14.TabIndex = 212;
            this.label14.Text = "Defendant:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.ForeColor = System.Drawing.Color.Black;
            this.label19.Location = new System.Drawing.Point(127, 20);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(90, 13);
            this.label19.TabIndex = 211;
            this.label19.Text = "Case Description:";
            // 
            // D_CaseForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.ControlBox = false;
            this.Controls.Add(this.decision);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.endDate);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.caseDate);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.startDate);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.requestDate);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.status);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.description);
            this.Controls.Add(this.place);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lawyer);
            this.Controls.Add(this.judgesList);
            this.Controls.Add(this.judges);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.defendant);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button11);
            this.Controls.Add(this.button12);
            this.Controls.Add(this.docComboBox);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.newLawyer);
            this.Controls.Add(this.assign);
            this.Controls.Add(this.allLawyers);
            this.Name = "D_CaseForm";
            this.Text = "Defendant case";
            this.Load += new System.EventHandler(this.D_CaseForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox newLawyer;
        private System.Windows.Forms.Button assign;
        private System.Windows.Forms.ComboBox allLawyers;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.ComboBox docComboBox;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.TextBox decision;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox endDate;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox caseDate;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox startDate;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox requestDate;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox status;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox description;
        private System.Windows.Forms.TextBox place;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox lawyer;
        private System.Windows.Forms.ListBox judgesList;
        private System.Windows.Forms.Label judges;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox defendant;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label19;
    }
}