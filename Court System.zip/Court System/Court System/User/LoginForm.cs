﻿using Oracle.DataAccess.Client;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace Court_System.User
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            this.StartPosition = FormStartPosition.CenterScreen;

            InitializeComponent();
        }

        private void UserTypeButton_CheckedChanged(object sender, EventArgs e)
        {
        }

        private void SignInBtn_Click(object sender, EventArgs e)
        {
            if (!User.IsValidEmail(email.Text.ToString()) ) {
                MessageBox.Show("Email address not valid");
                return;
            }
            if (password.Text.Length < 8)
            {
                MessageBox.Show("Password not valid , must contain at least 8 characters");
                return;
            }
            OracleCommand cmd = new OracleCommand();
            cmd.Connection = Program.conn;
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select user_id ,user_name,user_email ,user_type from users where user_email = : email and user_password = :password and user_type = :type";
            cmd.Parameters.Add("email", email.Text);
            cmd.Parameters.Add("password", password.Text);
            if (JudgeButton.Checked)
            {
                cmd.Parameters.Add("type", "judge");
            }
            else if (LawyerButton.Checked)
            {
                cmd.Parameters.Add("type", "lawyer");
            }
            else if (DefendantButton.Checked)
            {
                cmd.Parameters.Add("type", "defendant");
            }
            else if (CourtHeadButton.Checked)
            {
                cmd.Parameters.Add("type", "head");
            }
            try
            {
                OracleDataReader r = cmd.ExecuteReader();
                if (r.Read())
                {
                    Program.user = new User(r[0].ToString(), r[1].ToString(), r[2].ToString(), r[3].ToString());
                    MessageBox.Show("Welcome " + Program.user.Name);
                    this.Hide();
                    if (Program.user.Type == "defendant")
                    {
                        new Defendant.D_Home().Show();
                    }
                    else if (Program.user.Type == "judge")
                    {
                        new Judge.J_Home().Show();
                    }
                    else if (Program.user.Type == "lawyer")
                    {
                        new Lawyer.L_Home().Show();

                    }
                    else if (Program.user.Type == "head")
                    {
                        new Court_Head.H_Home().Show();

                    }
                }
                else {

                    MessageBox.Show("Error in login information");
                }
            }
            catch (Exception e00)
            {
                MessageBox.Show("Error \n" + e00.Message.ToString());
            }
        }

        private void RegisterBtn_Click(object sender, EventArgs e)
        {
            new RegistrationForm().Show();
            this.Close();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();

        }

        private void LoginForm_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            new MainForm().Show();
            this.Close();
        }
    }
}
