﻿using Oracle.DataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Court_System.User
{
    public class User
    {
        public User(string id, string name, string email, string type)
        {
            Id = id;
            Name = name;
            Email = email;
            Type = type;
        }

        public string Id { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string Type { get; set; }

        static public string get_user_name(string id)
        {
            if (id == "") return "";
            OracleCommand cmd = new OracleCommand("get_userName", Program.conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("id_", id);
            cmd.Parameters.Add("name_", OracleDbType.Varchar2, ParameterDirection.Output);
            cmd.Parameters["name_"].Size = 255;
            cmd.ExecuteNonQuery();
            return cmd.Parameters["name_"].Value.ToString();
        }
        static public string get_numberCases(string id)
        {
            if (id == "") return "";
            OracleCommand cmd = new OracleCommand("get_casesNumber", Program.conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("id_", id);
            cmd.Parameters.Add("COUNT_", OracleDbType.Int32, ParameterDirection.Output);
            cmd.ExecuteNonQuery();
            return cmd.Parameters["COUNT_"].Value.ToString();
        }


        static public bool IsValidEmail(string email)
        {
            var trimmedEmail = email.Trim();

            if (trimmedEmail.EndsWith("."))
            {
                return false; // suggested by @TK-421
            }
            try
            {
                var addr = new System.Net.Mail.MailAddress(email);
                return addr.Address == trimmedEmail;
            }
            catch
            {
                return false;
            }
        }
    }


}
