﻿using Oracle.DataAccess.Client;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Court_System.User
{
    public partial class RegistrationForm : Form
    {
        public RegistrationForm()
        {
            this.StartPosition = FormStartPosition.CenterScreen;

            InitializeComponent();
        }



        private void UserTypeButton_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void RegisterBtn_Click(object sender, EventArgs e)
        {
            if (!User.IsValidEmail(email.Text))
            {
                MessageBox.Show("Email address not valid");
                return;
            }
            if (password.Text.Length < 8)
            {
                MessageBox.Show("Password not valid , must contain at least 8 characters");
                return;
            }
            if (name.Text.Length < 4)
            {
                MessageBox.Show("Name not valid , must contain at least 4 characters");
                return;
            }
            OracleCommand cmd = new OracleCommand();
            cmd.Connection = Program.conn;
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "insert into users values(user_id_seq.nextval,:name,:email,:password,:type)";
            cmd.Parameters.Add("name", name.Text);
            cmd.Parameters.Add("email", email.Text);
            cmd.Parameters.Add("password", password.Text);
            if (JudgeButton.Checked)
            {
                cmd.Parameters.Add("type", "judge");
            }
            else if (LawyerButton.Checked)
            {
                cmd.Parameters.Add("type", "lawyer");
            }
            else if (DefendantButton.Checked)
            {
                cmd.Parameters.Add("type", "defendant");
            }
            else if (CourtHeadButton.Checked)
            {
                cmd.Parameters.Add("type", "head");
            }
            try
            {
                //  Block of code to try
                int r = cmd.ExecuteNonQuery();
                if (r != -1)
                {
                    MessageBox.Show("Done");
                    new LoginForm().Show();
                    this.Close();
                }
            }
            catch (Exception e00)
            {
                MessageBox.Show("Error \n"+e00.Message.ToString());
            }

           
        }


 

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            new LoginForm().Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void RegistrationForm_Load(object sender, EventArgs e)
        {

        }
    }
}
