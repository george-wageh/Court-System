﻿using System.Collections.Generic;

namespace Court_System.User
{
    partial class LoginForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.RegisterBtn = new System.Windows.Forms.Button();
            this.SignInBtn = new System.Windows.Forms.Button();
            this.password = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.email = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.CourtHeadButton = new System.Windows.Forms.RadioButton();
            this.DefendantButton = new System.Windows.Forms.RadioButton();
            this.LawyerButton = new System.Windows.Forms.RadioButton();
            this.JudgeButton = new System.Windows.Forms.RadioButton();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // RegisterBtn
            // 
            this.RegisterBtn.BackColor = System.Drawing.Color.Turquoise;
            this.RegisterBtn.Location = new System.Drawing.Point(426, 349);
            this.RegisterBtn.Name = "RegisterBtn";
            this.RegisterBtn.Size = new System.Drawing.Size(97, 28);
            this.RegisterBtn.TabIndex = 30;
            this.RegisterBtn.Text = "Register";
            this.RegisterBtn.UseVisualStyleBackColor = false;
            this.RegisterBtn.Click += new System.EventHandler(this.RegisterBtn_Click);
            // 
            // SignInBtn
            // 
            this.SignInBtn.BackColor = System.Drawing.Color.Turquoise;
            this.SignInBtn.Location = new System.Drawing.Point(277, 349);
            this.SignInBtn.Name = "SignInBtn";
            this.SignInBtn.Size = new System.Drawing.Size(97, 28);
            this.SignInBtn.TabIndex = 29;
            this.SignInBtn.Text = "Sign in";
            this.SignInBtn.UseVisualStyleBackColor = false;
            this.SignInBtn.Click += new System.EventHandler(this.SignInBtn_Click);
            // 
            // password
            // 
            this.password.Location = new System.Drawing.Point(288, 280);
            this.password.Name = "password";
            this.password.PasswordChar = '*';
            this.password.Size = new System.Drawing.Size(218, 20);
            this.password.TabIndex = 28;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(289, 262);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 13);
            this.label2.TabIndex = 27;
            this.label2.Text = "Password";
            // 
            // email
            // 
            this.email.Location = new System.Drawing.Point(288, 223);
            this.email.Name = "email";
            this.email.Size = new System.Drawing.Size(218, 20);
            this.email.TabIndex = 26;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(289, 204);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(32, 13);
            this.label1.TabIndex = 25;
            this.label1.Text = "Email";
            // 
            // CourtHeadButton
            // 
            this.CourtHeadButton.AutoSize = true;
            this.CourtHeadButton.Location = new System.Drawing.Point(359, 143);
            this.CourtHeadButton.Name = "CourtHeadButton";
            this.CourtHeadButton.Size = new System.Drawing.Size(79, 17);
            this.CourtHeadButton.TabIndex = 24;
            this.CourtHeadButton.TabStop = true;
            this.CourtHeadButton.Tag = "3";
            this.CourtHeadButton.Text = "Court Head";
            this.CourtHeadButton.UseVisualStyleBackColor = true;
            // 
            // DefendantButton
            // 
            this.DefendantButton.AutoSize = true;
            this.DefendantButton.Location = new System.Drawing.Point(359, 120);
            this.DefendantButton.Name = "DefendantButton";
            this.DefendantButton.Size = new System.Drawing.Size(75, 17);
            this.DefendantButton.TabIndex = 23;
            this.DefendantButton.TabStop = true;
            this.DefendantButton.Tag = "2";
            this.DefendantButton.Text = "Defendant";
            this.DefendantButton.UseVisualStyleBackColor = true;
            // 
            // LawyerButton
            // 
            this.LawyerButton.AutoSize = true;
            this.LawyerButton.Location = new System.Drawing.Point(359, 97);
            this.LawyerButton.Name = "LawyerButton";
            this.LawyerButton.Size = new System.Drawing.Size(59, 17);
            this.LawyerButton.TabIndex = 22;
            this.LawyerButton.TabStop = true;
            this.LawyerButton.Tag = "1";
            this.LawyerButton.Text = "Lawyer";
            this.LawyerButton.UseVisualStyleBackColor = true;
            // 
            // JudgeButton
            // 
            this.JudgeButton.AutoSize = true;
            this.JudgeButton.Checked = true;
            this.JudgeButton.Location = new System.Drawing.Point(359, 74);
            this.JudgeButton.Name = "JudgeButton";
            this.JudgeButton.Size = new System.Drawing.Size(54, 17);
            this.JudgeButton.TabIndex = 21;
            this.JudgeButton.TabStop = true;
            this.JudgeButton.Tag = "0";
            this.JudgeButton.Text = "Judge";
            this.JudgeButton.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(12, 51);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 60;
            this.button2.Text = "Exit";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(12, 12);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 61;
            this.button3.Text = "Back";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // LoginForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.ControlBox = false;
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.RegisterBtn);
            this.Controls.Add(this.SignInBtn);
            this.Controls.Add(this.password);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.email);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.CourtHeadButton);
            this.Controls.Add(this.DefendantButton);
            this.Controls.Add(this.LawyerButton);
            this.Controls.Add(this.JudgeButton);
            this.Name = "LoginForm";
            this.Text = "Login";
            this.Load += new System.EventHandler(this.LoginForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button RegisterBtn;
        private System.Windows.Forms.Button SignInBtn;
        private System.Windows.Forms.TextBox password;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox email;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton CourtHeadButton;
        private System.Windows.Forms.RadioButton DefendantButton;
        private System.Windows.Forms.RadioButton LawyerButton;
        private System.Windows.Forms.RadioButton JudgeButton;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
    }
}

