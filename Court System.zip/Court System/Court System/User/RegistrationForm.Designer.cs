﻿namespace Court_System.User
{
    partial class RegistrationForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.RegisterBtn = new System.Windows.Forms.Button();
            this.CourtHeadButton = new System.Windows.Forms.RadioButton();
            this.DefendantButton = new System.Windows.Forms.RadioButton();
            this.LawyerButton = new System.Windows.Forms.RadioButton();
            this.JudgeButton = new System.Windows.Forms.RadioButton();
            this.name = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.password = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.email = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // RegisterBtn
            // 
            this.RegisterBtn.BackColor = System.Drawing.Color.Turquoise;
            this.RegisterBtn.Location = new System.Drawing.Point(358, 364);
            this.RegisterBtn.Name = "RegisterBtn";
            this.RegisterBtn.Size = new System.Drawing.Size(97, 28);
            this.RegisterBtn.TabIndex = 40;
            this.RegisterBtn.Text = "Register";
            this.RegisterBtn.UseVisualStyleBackColor = false;
            this.RegisterBtn.Click += new System.EventHandler(this.RegisterBtn_Click);
            // 
            // CourtHeadButton
            // 
            this.CourtHeadButton.AutoSize = true;
            this.CourtHeadButton.Location = new System.Drawing.Point(358, 128);
            this.CourtHeadButton.Name = "CourtHeadButton";
            this.CourtHeadButton.Size = new System.Drawing.Size(79, 17);
            this.CourtHeadButton.TabIndex = 39;
            this.CourtHeadButton.Tag = "3";
            this.CourtHeadButton.Text = "Court Head";
            this.CourtHeadButton.UseVisualStyleBackColor = true;
            this.CourtHeadButton.CheckedChanged += new System.EventHandler(this.UserTypeButton_CheckedChanged);
            // 
            // DefendantButton
            // 
            this.DefendantButton.AutoSize = true;
            this.DefendantButton.Location = new System.Drawing.Point(358, 105);
            this.DefendantButton.Name = "DefendantButton";
            this.DefendantButton.Size = new System.Drawing.Size(75, 17);
            this.DefendantButton.TabIndex = 38;
            this.DefendantButton.Tag = "2";
            this.DefendantButton.Text = "Defendant";
            this.DefendantButton.UseVisualStyleBackColor = true;
            this.DefendantButton.CheckedChanged += new System.EventHandler(this.UserTypeButton_CheckedChanged);
            // 
            // LawyerButton
            // 
            this.LawyerButton.AutoSize = true;
            this.LawyerButton.Location = new System.Drawing.Point(358, 82);
            this.LawyerButton.Name = "LawyerButton";
            this.LawyerButton.Size = new System.Drawing.Size(59, 17);
            this.LawyerButton.TabIndex = 37;
            this.LawyerButton.Tag = "1";
            this.LawyerButton.Text = "Lawyer";
            this.LawyerButton.UseVisualStyleBackColor = true;
            this.LawyerButton.CheckedChanged += new System.EventHandler(this.UserTypeButton_CheckedChanged);
            // 
            // JudgeButton
            // 
            this.JudgeButton.AutoSize = true;
            this.JudgeButton.Checked = true;
            this.JudgeButton.Location = new System.Drawing.Point(358, 59);
            this.JudgeButton.Name = "JudgeButton";
            this.JudgeButton.Size = new System.Drawing.Size(54, 17);
            this.JudgeButton.TabIndex = 36;
            this.JudgeButton.TabStop = true;
            this.JudgeButton.Tag = "0";
            this.JudgeButton.Text = "Judge";
            this.JudgeButton.UseVisualStyleBackColor = true;
            this.JudgeButton.CheckedChanged += new System.EventHandler(this.UserTypeButton_CheckedChanged);
            // 
            // name
            // 
            this.name.Location = new System.Drawing.Point(291, 196);
            this.name.Name = "name";
            this.name.Size = new System.Drawing.Size(218, 20);
            this.name.TabIndex = 35;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(292, 177);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 13);
            this.label3.TabIndex = 34;
            this.label3.Text = "Name";
            // 
            // password
            // 
            this.password.Location = new System.Drawing.Point(291, 308);
            this.password.Name = "password";
            this.password.PasswordChar = '*';
            this.password.Size = new System.Drawing.Size(218, 20);
            this.password.TabIndex = 33;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(292, 290);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 13);
            this.label2.TabIndex = 32;
            this.label2.Text = "Password";
            // 
            // email
            // 
            this.email.Location = new System.Drawing.Point(291, 251);
            this.email.Name = "email";
            this.email.Size = new System.Drawing.Size(218, 20);
            this.email.TabIndex = 31;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(292, 232);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(32, 13);
            this.label1.TabIndex = 30;
            this.label1.Text = "Email";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(12, 59);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 60;
            this.button2.Text = "Exit";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(12, 12);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 59;
            this.button3.Text = "Back";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // RegistrationForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.ControlBox = false;
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.RegisterBtn);
            this.Controls.Add(this.CourtHeadButton);
            this.Controls.Add(this.DefendantButton);
            this.Controls.Add(this.LawyerButton);
            this.Controls.Add(this.JudgeButton);
            this.Controls.Add(this.name);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.password);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.email);
            this.Controls.Add(this.label1);
            this.Name = "RegistrationForm";
            this.Text = "Registration";
            this.Load += new System.EventHandler(this.RegistrationForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button RegisterBtn;
        private System.Windows.Forms.RadioButton CourtHeadButton;
        private System.Windows.Forms.RadioButton DefendantButton;
        private System.Windows.Forms.RadioButton LawyerButton;
        private System.Windows.Forms.RadioButton JudgeButton;
        private System.Windows.Forms.TextBox name;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox password;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox email;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
    }
}