﻿using CrystalDecisions.ReportAppServer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Court_System
{
    public partial class ReportForm : Form
    {
        public ReportForm()
        {
            InitializeComponent();
        }
       
        private void ReportForm_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
            int width = this.ClientSize.Width - 20;
            int height = this.ClientSize.Height - 200;
            crystalReportViewer1.Size = new Size(width, height);

          
        }

        private void button3_Click(object sender, EventArgs e)
        {
            new MainForm().Show();
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (radioLawyer.Checked)
            {
                CrystalReport1 report1 = new CrystalReport1();
                report1.SetParameterValue(0, email.Text);
                crystalReportViewer1.ReportSource = report1;
            }
            else if (radioDefendant.Checked) {
                CrystalReport2 report1 = new CrystalReport2();
                report1.SetParameterValue(0, email.Text);
                crystalReportViewer1.ReportSource = report1;

            }
          
        }
    }
}
