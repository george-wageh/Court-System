﻿using Court_System.Lawyer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.DataAccess.Client;
using Oracle.DataAccess.Types;
using Court_System.User;

namespace Court_System
{
    internal static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        static public OracleConnection conn;
        static public User.User user = null;
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            try
            {
                conn = new OracleConnection("Data source = orcl;User ID = scott;Password = tiger;");
                conn.Open();
            }
            catch (OracleException ex)
            {
                MessageBox.Show("Error: " + ex.Message);
               MessageBox.Show("Error code: " + ex.ErrorCode);
            }
            new MainForm().Show();
            Application.Run();
            conn.Close();
        }

    }

    class File_
    {
        public string name;
        public byte[] fileContent;
        public File_(string name, byte[] fileContent)
        {
            this.name = name;
            this.fileContent = fileContent;
        }
    }
}
