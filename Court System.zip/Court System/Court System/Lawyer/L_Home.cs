﻿using Court_System.User;
using Oracle.DataAccess.Client;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ToolTip;

namespace Court_System.Lawyer
{
    public partial class L_Home : Form
    {
        public L_Home()
        {
            this.StartPosition = FormStartPosition.CenterScreen;


            InitializeComponent();



        }

        private void OpenOrClosed_CheckedChanged(object sender, EventArgs e)
        {
            fillDataGrid();

        }
        private string getStatus() {

            if (newR.Checked)
            {
                return "new";
            }
            else if (opendR.Checked)
            {
                return "opened";
            }
            else if (closedR.Checked)
            {
                return "closed";
            }
            else if (adjournR.Checked)
            {
                return "adjournment";
            }
            else if (appealR.Checked)
            {
                return "appeal";
            }
            else return "";
        }
        private void openNew_Click(object sender, EventArgs e)
        {
            new Lawyer.L_AddNew().Show();
            this.Close();
        }


        private void button3_Click(object sender, EventArgs e)
        {
            Program.user = null;
            new LoginForm().Show();
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        OracleDataAdapter adapter = null;

        private void fillDataGrid() {
            string comd = "select CASE_ID,DESCRIPTION,REQUEST_DATE,START_DATE,CASE_DATE,PLACE from cases where LAWYER_ID = :userId and STATUS = :status";
            OracleCommand oracleCommand = new OracleCommand(comd);
            oracleCommand.Parameters.Add("userId", Program.user.Id);
            oracleCommand.Parameters.Add("status", getStatus());
            oracleCommand.Connection = Program.conn;
            adapter = new OracleDataAdapter(oracleCommand);
            DataSet ds = new DataSet();
            adapter.Fill(ds);
            casesDataGrid.DataSource = ds.Tables[0];
            numberCases.Text = User.User.get_numberCases(Program.user.Id);
        }

        private void L_Home_Load(object sender, EventArgs e)
        {
            fillDataGrid();
        }

        private void casesDataGrid_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.RowIndex < casesDataGrid.Rows.Count) {
                string CASE_ID = casesDataGrid.Rows[e.RowIndex].Cells[0].Value.ToString();
                new L_CaseForm(CASE_ID).Show();
                this.Close();
            }
         
        }
    }
}
