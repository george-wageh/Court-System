﻿namespace Court_System.Lawyer
{
    partial class L_CaseForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.appealButton = new System.Windows.Forms.Button();
            this.withdrawButton = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.resignButton = new System.Windows.Forms.Button();
            this.adjournmentButton = new System.Windows.Forms.Button();
            this.status = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.description = new System.Windows.Forms.TextBox();
            this.place = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lawyer = new System.Windows.Forms.TextBox();
            this.uploadPdf = new System.Windows.Forms.Button();
            this.savePdf = new System.Windows.Forms.Button();
            this.judgesList = new System.Windows.Forms.ListBox();
            this.docComboBox = new System.Windows.Forms.ComboBox();
            this.judges = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.defendant = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.endDate = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.caseDate = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.startDate = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.requestDate = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.save = new System.Windows.Forms.Button();
            this.decision = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // appealButton
            // 
            this.appealButton.Enabled = false;
            this.appealButton.Location = new System.Drawing.Point(168, 46);
            this.appealButton.Name = "appealButton";
            this.appealButton.Size = new System.Drawing.Size(83, 46);
            this.appealButton.TabIndex = 29;
            this.appealButton.Text = "Request an appeal";
            this.appealButton.UseVisualStyleBackColor = true;
            this.appealButton.Click += new System.EventHandler(this.appealButton_Click);
            // 
            // withdrawButton
            // 
            this.withdrawButton.Enabled = false;
            this.withdrawButton.Location = new System.Drawing.Point(25, 46);
            this.withdrawButton.Name = "withdrawButton";
            this.withdrawButton.Size = new System.Drawing.Size(83, 46);
            this.withdrawButton.TabIndex = 27;
            this.withdrawButton.Text = "Withdraw the case";
            this.withdrawButton.UseVisualStyleBackColor = true;
            this.withdrawButton.Click += new System.EventHandler(this.button2_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.resignButton);
            this.groupBox1.Controls.Add(this.appealButton);
            this.groupBox1.Controls.Add(this.adjournmentButton);
            this.groupBox1.Controls.Add(this.withdrawButton);
            this.groupBox1.Location = new System.Drawing.Point(136, 396);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(541, 109);
            this.groupBox1.TabIndex = 46;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Lawyer Controls";
            // 
            // resignButton
            // 
            this.resignButton.Enabled = false;
            this.resignButton.Location = new System.Drawing.Point(435, 46);
            this.resignButton.Name = "resignButton";
            this.resignButton.Size = new System.Drawing.Size(83, 46);
            this.resignButton.TabIndex = 32;
            this.resignButton.Text = "Resign";
            this.resignButton.UseVisualStyleBackColor = true;
            this.resignButton.Click += new System.EventHandler(this.button1_Click);
            // 
            // adjournmentButton
            // 
            this.adjournmentButton.Enabled = false;
            this.adjournmentButton.Location = new System.Drawing.Point(303, 46);
            this.adjournmentButton.Name = "adjournmentButton";
            this.adjournmentButton.Size = new System.Drawing.Size(83, 46);
            this.adjournmentButton.TabIndex = 28;
            this.adjournmentButton.Text = "Request an adjournment";
            this.adjournmentButton.UseVisualStyleBackColor = true;
            this.adjournmentButton.Click += new System.EventHandler(this.adjournmentButton_Click);
            // 
            // status
            // 
            this.status.ForeColor = System.Drawing.Color.Black;
            this.status.Location = new System.Drawing.Point(350, 109);
            this.status.Name = "status";
            this.status.ReadOnly = true;
            this.status.Size = new System.Drawing.Size(100, 20);
            this.status.TabIndex = 144;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.ForeColor = System.Drawing.Color.Black;
            this.label15.Location = new System.Drawing.Point(330, 83);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(40, 13);
            this.label15.TabIndex = 143;
            this.label15.Text = "Status:";
            // 
            // description
            // 
            this.description.ForeColor = System.Drawing.Color.Black;
            this.description.Location = new System.Drawing.Point(174, 46);
            this.description.Multiline = true;
            this.description.Name = "description";
            this.description.Size = new System.Drawing.Size(100, 68);
            this.description.TabIndex = 142;
            // 
            // place
            // 
            this.place.ForeColor = System.Drawing.Color.Black;
            this.place.Location = new System.Drawing.Point(520, 173);
            this.place.Name = "place";
            this.place.ReadOnly = true;
            this.place.Size = new System.Drawing.Size(100, 20);
            this.place.TabIndex = 141;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(500, 147);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(37, 13);
            this.label1.TabIndex = 140;
            this.label1.Text = "Place:";
            // 
            // lawyer
            // 
            this.lawyer.ForeColor = System.Drawing.Color.Black;
            this.lawyer.Location = new System.Drawing.Point(520, 236);
            this.lawyer.Name = "lawyer";
            this.lawyer.ReadOnly = true;
            this.lawyer.Size = new System.Drawing.Size(100, 20);
            this.lawyer.TabIndex = 139;
            // 
            // uploadPdf
            // 
            this.uploadPdf.Location = new System.Drawing.Point(431, 288);
            this.uploadPdf.Name = "uploadPdf";
            this.uploadPdf.Size = new System.Drawing.Size(106, 23);
            this.uploadPdf.TabIndex = 138;
            this.uploadPdf.Text = "Upload pdf";
            this.uploadPdf.UseVisualStyleBackColor = true;
            this.uploadPdf.Click += new System.EventHandler(this.uploadPdf_Click);
            // 
            // savePdf
            // 
            this.savePdf.Location = new System.Drawing.Point(300, 288);
            this.savePdf.Name = "savePdf";
            this.savePdf.Size = new System.Drawing.Size(111, 23);
            this.savePdf.TabIndex = 137;
            this.savePdf.Text = "Save then open pdf";
            this.savePdf.UseVisualStyleBackColor = true;
            this.savePdf.Click += new System.EventHandler(this.savePdf_Click);
            // 
            // judgesList
            // 
            this.judgesList.ForeColor = System.Drawing.Color.Black;
            this.judgesList.FormattingEnabled = true;
            this.judgesList.Location = new System.Drawing.Point(663, 44);
            this.judgesList.Name = "judgesList";
            this.judgesList.Size = new System.Drawing.Size(100, 82);
            this.judgesList.TabIndex = 136;
            // 
            // docComboBox
            // 
            this.docComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.docComboBox.FormattingEnabled = true;
            this.docComboBox.Location = new System.Drawing.Point(177, 288);
            this.docComboBox.Name = "docComboBox";
            this.docComboBox.Size = new System.Drawing.Size(103, 21);
            this.docComboBox.TabIndex = 135;
            // 
            // judges
            // 
            this.judges.AutoSize = true;
            this.judges.ForeColor = System.Drawing.Color.Black;
            this.judges.Location = new System.Drawing.Point(645, 19);
            this.judges.Name = "judges";
            this.judges.Size = new System.Drawing.Size(44, 13);
            this.judges.TabIndex = 134;
            this.judges.Text = "Judges:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.ForeColor = System.Drawing.Color.Black;
            this.label13.Location = new System.Drawing.Point(500, 209);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(44, 13);
            this.label13.TabIndex = 133;
            this.label13.Text = "Lawyer:";
            // 
            // defendant
            // 
            this.defendant.ForeColor = System.Drawing.Color.Black;
            this.defendant.Location = new System.Drawing.Point(350, 44);
            this.defendant.Name = "defendant";
            this.defendant.ReadOnly = true;
            this.defendant.Size = new System.Drawing.Size(100, 20);
            this.defendant.TabIndex = 132;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.ForeColor = System.Drawing.Color.Black;
            this.label14.Location = new System.Drawing.Point(330, 18);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(60, 13);
            this.label14.TabIndex = 131;
            this.label14.Text = "Defendant:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(160, 263);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(60, 13);
            this.label16.TabIndex = 130;
            this.label16.Text = "Legal Files:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.ForeColor = System.Drawing.Color.Black;
            this.label19.Location = new System.Drawing.Point(157, 19);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(90, 13);
            this.label19.TabIndex = 125;
            this.label19.Text = "Case Description:";
            // 
            // endDate
            // 
            this.endDate.ForeColor = System.Drawing.Color.Black;
            this.endDate.Location = new System.Drawing.Point(520, 109);
            this.endDate.Name = "endDate";
            this.endDate.ReadOnly = true;
            this.endDate.Size = new System.Drawing.Size(100, 20);
            this.endDate.TabIndex = 204;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(500, 83);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 13);
            this.label3.TabIndex = 203;
            this.label3.Text = "End Date:";
            // 
            // caseDate
            // 
            this.caseDate.ForeColor = System.Drawing.Color.Black;
            this.caseDate.Location = new System.Drawing.Point(520, 44);
            this.caseDate.Name = "caseDate";
            this.caseDate.ReadOnly = true;
            this.caseDate.Size = new System.Drawing.Size(100, 20);
            this.caseDate.TabIndex = 202;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(335, 147);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(76, 13);
            this.label2.TabIndex = 201;
            this.label2.Text = "Request Date:";
            // 
            // startDate
            // 
            this.startDate.ForeColor = System.Drawing.Color.Black;
            this.startDate.Location = new System.Drawing.Point(350, 236);
            this.startDate.Name = "startDate";
            this.startDate.ReadOnly = true;
            this.startDate.Size = new System.Drawing.Size(100, 20);
            this.startDate.TabIndex = 200;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.ForeColor = System.Drawing.Color.Black;
            this.label17.Location = new System.Drawing.Point(502, 22);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(60, 13);
            this.label17.TabIndex = 199;
            this.label17.Text = "Case Date:";
            // 
            // requestDate
            // 
            this.requestDate.ForeColor = System.Drawing.Color.Black;
            this.requestDate.Location = new System.Drawing.Point(350, 173);
            this.requestDate.Name = "requestDate";
            this.requestDate.ReadOnly = true;
            this.requestDate.Size = new System.Drawing.Size(100, 20);
            this.requestDate.TabIndex = 198;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.ForeColor = System.Drawing.Color.Black;
            this.label18.Location = new System.Drawing.Point(332, 209);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(58, 13);
            this.label18.TabIndex = 197;
            this.label18.Text = "Start Date:";
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(12, 59);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 23);
            this.button5.TabIndex = 206;
            this.button5.Text = "Exit";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(12, 12);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(75, 23);
            this.button6.TabIndex = 205;
            this.button6.Text = "Back";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // save
            // 
            this.save.Location = new System.Drawing.Point(369, 342);
            this.save.Name = "save";
            this.save.Size = new System.Drawing.Size(81, 23);
            this.save.TabIndex = 207;
            this.save.Text = "Save";
            this.save.UseVisualStyleBackColor = true;
            this.save.Click += new System.EventHandler(this.save_Click);
            // 
            // decision
            // 
            this.decision.Location = new System.Drawing.Point(177, 163);
            this.decision.Multiline = true;
            this.decision.Name = "decision";
            this.decision.ReadOnly = true;
            this.decision.Size = new System.Drawing.Size(100, 68);
            this.decision.TabIndex = 210;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(160, 136);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(75, 13);
            this.label4.TabIndex = 209;
            this.label4.Text = "Case Decision";
            // 
            // L_CaseForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 517);
            this.ControlBox = false;
            this.Controls.Add(this.decision);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.save);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.endDate);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.caseDate);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.startDate);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.requestDate);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.status);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.description);
            this.Controls.Add(this.place);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lawyer);
            this.Controls.Add(this.uploadPdf);
            this.Controls.Add(this.savePdf);
            this.Controls.Add(this.judgesList);
            this.Controls.Add(this.docComboBox);
            this.Controls.Add(this.judges);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.defendant);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.groupBox1);
            this.Name = "L_CaseForm";
            this.Text = "Lawyer case";
            this.Load += new System.EventHandler(this.L_CaseForm_Load);
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button appealButton;
        private System.Windows.Forms.Button withdrawButton;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button adjournmentButton;
        private System.Windows.Forms.Button resignButton;
        private System.Windows.Forms.TextBox status;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox description;
        private System.Windows.Forms.TextBox place;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox lawyer;
        private System.Windows.Forms.Button uploadPdf;
        private System.Windows.Forms.Button savePdf;
        private System.Windows.Forms.ListBox judgesList;
        private System.Windows.Forms.ComboBox docComboBox;
        private System.Windows.Forms.Label judges;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox defendant;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox endDate;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox caseDate;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox startDate;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox requestDate;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button save;
        private System.Windows.Forms.TextBox decision;
        private System.Windows.Forms.Label label4;
    }
}