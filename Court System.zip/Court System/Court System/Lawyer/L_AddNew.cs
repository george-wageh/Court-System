﻿using Oracle.DataAccess.Client;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using System.Xml.Linq;
using static System.Net.WebRequestMethods;
using File = System.IO.File;
using System.Diagnostics;

namespace Court_System.Lawyer
{
    public partial class L_AddNew : Form
    {
        public L_AddNew()
        {
            this.StartPosition = FormStartPosition.CenterScreen;

            InitializeComponent();
            filees = new List<File_>();
        }

        private void AddNew_Load(object sender, EventArgs e)
        {

            OracleCommand cmd = new OracleCommand();
            cmd.Connection = Program.conn;
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select user_id from users where user_type = :defe";
            cmd.Parameters.Add("defe", "defendant");
            OracleDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                defendantComboBox.Items.Add(dr[0]);
            }
        }



        private void L_AddNew_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                e.Cancel = true;
                new L_Home().Show();
                this.Close();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            new L_Home().Show();
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void defendantComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {

            defendantName.Text = User.User.get_user_name(defendantComboBox.Text.ToString());
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OracleCommand cmd = new OracleCommand();
            cmd.Connection = Program.conn;
            cmd.CommandType = CommandType.Text;

            OracleCommand loCmd = Program.conn.CreateCommand();
            loCmd.CommandType = CommandType.Text;
            loCmd.CommandText = "select CASE_ID_SEQ.nextval from dual";
            string case_id = Convert.ToString(loCmd.ExecuteScalar());

            cmd.CommandText = "insert into cases values(:case_id,:DEFENDANT_ID,:LAWYER_ID,:STATUS,null,null,null,:REQUEST_DATE,null,:DESCRIPTION , null)";
            cmd.Parameters.Add("case_id", case_id);
            cmd.Parameters.Add("DEFENDANT_ID", defendantComboBox.Text);
            cmd.Parameters.Add("LAWYER_ID", Program.user.Id);
            cmd.Parameters.Add("STATUS", "new");
            cmd.Parameters.Add("REQUEST_DATE", DateTime.Now);
            cmd.Parameters.Add("DESCRIPTION", case_des.Text);
            if (defendantComboBox.Text == "") {
                MessageBox.Show("Defendant is not valid");
                return;

            }
            if (case_des.Text == "")
            {
                MessageBox.Show("Description is empty !!");
                return;
            }
            if (defendantComboBox.Text != "" && case_des.Text != "") { 
                try
                {
                    int r = cmd.ExecuteNonQuery();
                    if (r != -1)
                    {

                        foreach (File_ f in filees)
                        {

                            OracleCommand cmd1 = new OracleCommand();
                            cmd1.Connection = Program.conn;
                            cmd1.CommandType = CommandType.Text;
                            cmd1.CommandText = "insert into CASE_DOCUMENTS values(:CASE_ID,:FILENAME,:FILEDATA)";
                            cmd1.Parameters.Add("CASE_ID", case_id);
                            cmd1.Parameters.Add("FILENAME", f.name);
                            cmd1.Parameters.Add("FILEDATA", f.fileContent);

                            try
                            {
                                cmd1.ExecuteNonQuery();
                            }
                            catch (Exception e00)
                            {
                                MessageBox.Show("Error \n" + e00.Message.ToString());
                            }
                        }
                        MessageBox.Show("Done");
                        new L_Home().Show();
                        this.Close();
                    }
                }
                catch (Exception e00)
                {
                    MessageBox.Show("Error \n" + e00.Message.ToString());
                }
            }
        }
    

        private List<File_> filees; 
   

        private void button6_Click(object sender, EventArgs e)
        {
            //insert pdf
            OracleCommand loCmd = Program.conn.CreateCommand();
            loCmd.CommandType = CommandType.Text;
            loCmd.CommandText = "select DOCUMENT_ID_SEQ.nextval from dual";
            string document_id = Convert.ToString(loCmd.ExecuteScalar());
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            openFileDialog1.Filter = "|*.pdf";
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                string filePath = openFileDialog1.FileName;
                byte[] fileContent = File.ReadAllBytes(filePath);
                string fileName = document_id + "_" + Path.GetFileName(filePath);
                DocComboBox.Items.Add( fileName);
                filees.Add(new File_(fileName, fileContent));
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            // open pdf
            //string fileName = DocComboBox.Text;
            //User.ShowPdfForm showPdfForm = new User.ShowPdfForm(fileName, Byte[] fileContent);


        }
    }
}
