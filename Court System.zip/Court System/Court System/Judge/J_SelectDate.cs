﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Court_System.Judge
{
    public partial class J_SelectDate : Form
    {
        public J_SelectDate()
        {
            InitializeComponent();
        }
        public string Result { get; set; }

        private void J_SelectDate_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Result = dateTimePicker1.Value.ToString();
            DialogResult = DialogResult.OK;
        }
    }
}
