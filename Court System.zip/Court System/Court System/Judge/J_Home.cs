﻿using Court_System.Lawyer;
using Court_System.User;
using Oracle.DataAccess.Client;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Court_System.Judge
{
    public partial class J_Home : Form
    {
        public J_Home()
        {

            this.StartPosition = FormStartPosition.CenterScreen;

            InitializeComponent();

        }
        private string getStatus()
        {
            if (opendR.Checked)
            {
                return "opened";
            }
            else if (closedR.Checked)
            {
                return "closed";
            }
            else if (adjournR.Checked)
            {
                return "adjournment";
            }
            else if (appealR.Checked)
            {
                return "appeal";
            }
            else return "";
        }
        private void fillDataGrid() {
            OracleCommand command = new OracleCommand();
            command.Connection = Program.conn;
            command.CommandType = CommandType.StoredProcedure;
            command.CommandText = "get_judge_cases";
            command.Parameters.Add("JUDGE_ID", Program.user.Id);
            command.Parameters.Add("status", getStatus());
            command.Parameters.Add("cases", OracleDbType.RefCursor, ParameterDirection.Output);
            OracleDataAdapter adapter = new OracleDataAdapter(command);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            casesDataGrid.DataSource = dt;
        }
        private void J_Home_Load(object sender, EventArgs e)
        {
            fillDataGrid();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Program.user = null;
            new LoginForm().Show();
            this.Close();
        }

        private void casesDataGrid_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.RowIndex < casesDataGrid.Rows.Count) {
                string CASE_ID = casesDataGrid.Rows[e.RowIndex].Cells[0].Value.ToString();
                new J_CaseForm(CASE_ID).Show();
                this.Close();
            }
         
        }

        private void newR_CheckedChanged(object sender, EventArgs e)
        {
            fillDataGrid();

        }
    }
}
