﻿namespace Court_System.Court_Head
{
    partial class RemoveJudge
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label11 = new System.Windows.Forms.Label();
            this.judgeName = new System.Windows.Forms.TextBox();
            this.button10 = new System.Windows.Forms.Button();
            this.allJudes = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(217, 76);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(35, 13);
            this.label11.TabIndex = 226;
            this.label11.Text = "Name";
            // 
            // judgeName
            // 
            this.judgeName.Location = new System.Drawing.Point(258, 74);
            this.judgeName.Name = "judgeName";
            this.judgeName.ReadOnly = true;
            this.judgeName.Size = new System.Drawing.Size(91, 20);
            this.judgeName.TabIndex = 225;
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(144, 139);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(114, 23);
            this.button10.TabIndex = 223;
            this.button10.Text = "Remove judge";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // allJudes
            // 
            this.allJudes.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.allJudes.FormattingEnabled = true;
            this.allJudes.Location = new System.Drawing.Point(76, 73);
            this.allJudes.Name = "allJudes";
            this.allJudes.Size = new System.Drawing.Size(132, 21);
            this.allJudes.TabIndex = 224;
            this.allJudes.SelectedIndexChanged += new System.EventHandler(this.allJudes_SelectedIndexChanged);
            // 
            // RemoveJudge
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(431, 383);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.judgeName);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.allJudes);
            this.Name = "RemoveJudge";
            this.Text = "Remove judge";
            this.Load += new System.EventHandler(this.RemoveJudge_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox judgeName;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.ComboBox allJudes;
    }
}