﻿using System;

namespace Court_System.Court_Head
{
    partial class H_Case
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.remove = new System.Windows.Forms.Button();
            this.refuse = new System.Windows.Forms.Button();
            this.accept = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.decision = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.endDate = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.caseDate = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.startDate = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.requestDate = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.status = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.description = new System.Windows.Forms.TextBox();
            this.place = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lawyer = new System.Windows.Forms.TextBox();
            this.savePdf = new System.Windows.Forms.Button();
            this.judgesList = new System.Windows.Forms.ListBox();
            this.docComboBox = new System.Windows.Forms.ComboBox();
            this.judges = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.defendant = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.remove);
            this.groupBox1.Controls.Add(this.refuse);
            this.groupBox1.Controls.Add(this.accept);
            this.groupBox1.Location = new System.Drawing.Point(57, 373);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(713, 65);
            this.groupBox1.TabIndex = 138;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Head Controls";
            // 
            // remove
            // 
            this.remove.Enabled = false;
            this.remove.Location = new System.Drawing.Point(438, 19);
            this.remove.Name = "remove";
            this.remove.Size = new System.Drawing.Size(94, 37);
            this.remove.TabIndex = 235;
            this.remove.Text = "Remove case";
            this.remove.UseVisualStyleBackColor = true;
            this.remove.Click += new System.EventHandler(this.button1_Click);
            // 
            // refuse
            // 
            this.refuse.Enabled = false;
            this.refuse.Location = new System.Drawing.Point(307, 19);
            this.refuse.Name = "refuse";
            this.refuse.Size = new System.Drawing.Size(94, 37);
            this.refuse.TabIndex = 123;
            this.refuse.Text = "Refuse case";
            this.refuse.UseVisualStyleBackColor = true;
            this.refuse.Click += new System.EventHandler(this.refuse_Click);
            // 
            // accept
            // 
            this.accept.Enabled = false;
            this.accept.Location = new System.Drawing.Point(166, 18);
            this.accept.Name = "accept";
            this.accept.Size = new System.Drawing.Size(106, 37);
            this.accept.TabIndex = 234;
            this.accept.Text = "Accept case";
            this.accept.UseVisualStyleBackColor = true;
            this.accept.Click += new System.EventHandler(this.accept_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(12, 59);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 198;
            this.button4.Text = "Exit";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(12, 12);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 23);
            this.button5.TabIndex = 197;
            this.button5.Text = "Back";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // decision
            // 
            this.decision.Location = new System.Drawing.Point(148, 164);
            this.decision.Multiline = true;
            this.decision.Name = "decision";
            this.decision.ReadOnly = true;
            this.decision.Size = new System.Drawing.Size(100, 68);
            this.decision.TabIndex = 236;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(131, 137);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(75, 13);
            this.label4.TabIndex = 235;
            this.label4.Text = "Case Decision";
            // 
            // endDate
            // 
            this.endDate.ForeColor = System.Drawing.Color.Black;
            this.endDate.Location = new System.Drawing.Point(491, 119);
            this.endDate.Name = "endDate";
            this.endDate.ReadOnly = true;
            this.endDate.Size = new System.Drawing.Size(100, 20);
            this.endDate.TabIndex = 233;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(471, 93);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 13);
            this.label3.TabIndex = 232;
            this.label3.Text = "End Date:";
            // 
            // caseDate
            // 
            this.caseDate.ForeColor = System.Drawing.Color.Black;
            this.caseDate.Location = new System.Drawing.Point(491, 45);
            this.caseDate.Name = "caseDate";
            this.caseDate.ReadOnly = true;
            this.caseDate.Size = new System.Drawing.Size(100, 20);
            this.caseDate.TabIndex = 231;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(306, 148);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(76, 13);
            this.label2.TabIndex = 230;
            this.label2.Text = "Request Date:";
            // 
            // startDate
            // 
            this.startDate.ForeColor = System.Drawing.Color.Black;
            this.startDate.Location = new System.Drawing.Point(321, 246);
            this.startDate.Name = "startDate";
            this.startDate.ReadOnly = true;
            this.startDate.Size = new System.Drawing.Size(100, 20);
            this.startDate.TabIndex = 229;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.ForeColor = System.Drawing.Color.Black;
            this.label17.Location = new System.Drawing.Point(473, 23);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(60, 13);
            this.label17.TabIndex = 228;
            this.label17.Text = "Case Date:";
            // 
            // requestDate
            // 
            this.requestDate.ForeColor = System.Drawing.Color.Black;
            this.requestDate.Location = new System.Drawing.Point(321, 174);
            this.requestDate.Name = "requestDate";
            this.requestDate.ReadOnly = true;
            this.requestDate.Size = new System.Drawing.Size(100, 20);
            this.requestDate.TabIndex = 227;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.ForeColor = System.Drawing.Color.Black;
            this.label18.Location = new System.Drawing.Point(303, 219);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(58, 13);
            this.label18.TabIndex = 226;
            this.label18.Text = "Start Date:";
            // 
            // status
            // 
            this.status.ForeColor = System.Drawing.Color.Black;
            this.status.Location = new System.Drawing.Point(321, 110);
            this.status.Name = "status";
            this.status.ReadOnly = true;
            this.status.Size = new System.Drawing.Size(100, 20);
            this.status.TabIndex = 225;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.ForeColor = System.Drawing.Color.Black;
            this.label15.Location = new System.Drawing.Point(301, 84);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(40, 13);
            this.label15.TabIndex = 224;
            this.label15.Text = "Status:";
            // 
            // description
            // 
            this.description.ForeColor = System.Drawing.Color.Black;
            this.description.Location = new System.Drawing.Point(145, 47);
            this.description.Multiline = true;
            this.description.Name = "description";
            this.description.ReadOnly = true;
            this.description.Size = new System.Drawing.Size(100, 68);
            this.description.TabIndex = 223;
            // 
            // place
            // 
            this.place.ForeColor = System.Drawing.Color.Black;
            this.place.Location = new System.Drawing.Point(491, 183);
            this.place.Name = "place";
            this.place.ReadOnly = true;
            this.place.Size = new System.Drawing.Size(100, 20);
            this.place.TabIndex = 222;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(471, 157);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(37, 13);
            this.label1.TabIndex = 221;
            this.label1.Text = "Place:";
            // 
            // lawyer
            // 
            this.lawyer.ForeColor = System.Drawing.Color.Black;
            this.lawyer.Location = new System.Drawing.Point(491, 246);
            this.lawyer.Name = "lawyer";
            this.lawyer.ReadOnly = true;
            this.lawyer.Size = new System.Drawing.Size(100, 20);
            this.lawyer.TabIndex = 220;
            // 
            // savePdf
            // 
            this.savePdf.Location = new System.Drawing.Point(271, 289);
            this.savePdf.Name = "savePdf";
            this.savePdf.Size = new System.Drawing.Size(111, 23);
            this.savePdf.TabIndex = 219;
            this.savePdf.Text = "Save then open pdf";
            this.savePdf.UseVisualStyleBackColor = true;
            this.savePdf.Click += new System.EventHandler(this.savePdf_Click);
            // 
            // judgesList
            // 
            this.judgesList.ForeColor = System.Drawing.Color.Black;
            this.judgesList.FormattingEnabled = true;
            this.judgesList.Location = new System.Drawing.Point(634, 45);
            this.judgesList.Name = "judgesList";
            this.judgesList.Size = new System.Drawing.Size(100, 82);
            this.judgesList.TabIndex = 218;
            // 
            // docComboBox
            // 
            this.docComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.docComboBox.FormattingEnabled = true;
            this.docComboBox.Location = new System.Drawing.Point(148, 289);
            this.docComboBox.Name = "docComboBox";
            this.docComboBox.Size = new System.Drawing.Size(103, 21);
            this.docComboBox.TabIndex = 217;
            // 
            // judges
            // 
            this.judges.AutoSize = true;
            this.judges.ForeColor = System.Drawing.Color.Black;
            this.judges.Location = new System.Drawing.Point(616, 20);
            this.judges.Name = "judges";
            this.judges.Size = new System.Drawing.Size(44, 13);
            this.judges.TabIndex = 216;
            this.judges.Text = "Judges:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.ForeColor = System.Drawing.Color.Black;
            this.label13.Location = new System.Drawing.Point(471, 219);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(44, 13);
            this.label13.TabIndex = 215;
            this.label13.Text = "Lawyer:";
            // 
            // defendant
            // 
            this.defendant.ForeColor = System.Drawing.Color.Black;
            this.defendant.Location = new System.Drawing.Point(321, 45);
            this.defendant.Name = "defendant";
            this.defendant.ReadOnly = true;
            this.defendant.Size = new System.Drawing.Size(100, 20);
            this.defendant.TabIndex = 214;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.ForeColor = System.Drawing.Color.Black;
            this.label14.Location = new System.Drawing.Point(301, 19);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(60, 13);
            this.label14.TabIndex = 213;
            this.label14.Text = "Defendant:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(131, 264);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(60, 13);
            this.label16.TabIndex = 212;
            this.label16.Text = "Legal Files:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.ForeColor = System.Drawing.Color.Black;
            this.label19.Location = new System.Drawing.Point(128, 20);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(90, 13);
            this.label19.TabIndex = 211;
            this.label19.Text = "Case Description:";
            // 
            // H_Case
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.ControlBox = false;
            this.Controls.Add(this.decision);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.endDate);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.caseDate);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.startDate);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.requestDate);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.status);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.description);
            this.Controls.Add(this.place);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lawyer);
            this.Controls.Add(this.savePdf);
            this.Controls.Add(this.judgesList);
            this.Controls.Add(this.docComboBox);
            this.Controls.Add(this.judges);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.defendant);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.groupBox1);
            this.Name = "H_Case";
            this.Text = "Head case";
            this.Load += new System.EventHandler(this.H_Case_Load);
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button refuse;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.TextBox decision;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox endDate;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox caseDate;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox startDate;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox requestDate;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox status;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox description;
        private System.Windows.Forms.TextBox place;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox lawyer;
        private System.Windows.Forms.Button savePdf;
        private System.Windows.Forms.ListBox judgesList;
        private System.Windows.Forms.ComboBox docComboBox;
        private System.Windows.Forms.Label judges;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox defendant;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Button accept;
        private System.Windows.Forms.Button remove;
    }
}