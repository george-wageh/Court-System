﻿using Oracle.DataAccess.Client;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Court_System.Court_Head
{
    public partial class Acceptance_Form : Form
    {
        string case_id = "";
        List<string> judgesList_ids = new List<string>();
        OracleDataAdapter adapter = null;
        DataSet ds = null;
        public Acceptance_Form(string case_id, DataSet ds, OracleDataAdapter adapter)
        {
            InitializeComponent();
            this.case_id = case_id;
            this.ds = ds;
            this.adapter = adapter;

        }

        private void save_Click(object sender, EventArgs e)
        {
            //save
            if (judgesList.Items.Count == 0)
            {
                MessageBox.Show("At least one judge is required");
                return;
            }
            ds.Tables[0].Rows[0]["STATUS"] = "opened";
            string selected_date = dateTimePicker1.Value.ToString();
            ds.Tables[0].Rows[0]["CASE_DATE"] = selected_date;
            ds.Tables[0].Rows[0]["START_DATE"] = DateTime.Now;
            ds.Tables[0].Rows[0]["PLACE"] = place.Text;
            OracleCommandBuilder oracleCommandBuilder = new OracleCommandBuilder(adapter);
            adapter.Update(ds.Tables[0]);
            int sizeJudgesList_ids = judgesList_ids.Count;
            foreach (string id in judgesList_ids)
            {
                OracleCommand cmd1 = new OracleCommand();
                cmd1.Connection = Program.conn;
                cmd1.CommandType = CommandType.Text;
                cmd1.CommandText = "insert into CASE_JUDGES values(:CASE_ID,:JUDGE_ID)";
                cmd1.Parameters.Add("CASE_ID", case_id);
                cmd1.Parameters.Add("JUDGE_ID", id);
                try
                {
                    cmd1.ExecuteNonQuery();
                    sizeJudgesList_ids--;
                }
                catch (Exception e00)
                {
                    MessageBox.Show("Error \n" + e00.Message.ToString());
                }
            }
            if (sizeJudgesList_ids == 0)
            {
                MessageBox.Show("Done");
                this.Close();
            }
        }

        private void Acceptance_Form_Load(object sender, EventArgs e)
        {

            OracleCommand cmd = new OracleCommand();
            cmd.Connection = Program.conn;
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select user_id from users where user_type = :defe";
            cmd.Parameters.Add("defe", "judge");
            OracleDataReader dr0 = cmd.ExecuteReader();
            while (dr0.Read())
            {
              allJudes.Items.Add(dr0[0].ToString());
            }
            judgesList_ids.Clear();
        }

        private void allJudes_SelectedIndexChanged(object sender, EventArgs e)
        {
            judgeName.Text = User.User.get_user_name(allJudes.Text.ToString());

        }

        private void button10_Click(object sender, EventArgs e)
        {
            //assign 
            if (allJudes.Text == "") return;
            judgesList_ids.Add(allJudes.Text.ToString());
            judgesList.Items.Add(User.User.get_user_name(allJudes.Text.ToString()));
            allJudes.Items.Remove(allJudes.Text.ToString());
        }
    }
}
