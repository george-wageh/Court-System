﻿using Court_System.Lawyer;
using Oracle.DataAccess.Client;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Court_System.Court_Head
{
    public partial class H_Case : Form
    {
        string Case_id = "";
        public H_Case(string Case_id)
        {
            this.Case_id = Case_id;
            this.StartPosition = FormStartPosition.CenterScreen;


            InitializeComponent();
        }
        OracleDataAdapter adapter = null;
        DataSet ds = null;
        private void H_Case_Load(object sender, EventArgs e)
        {

            string comd = "select * from cases where CASE_ID=" + Case_id;
            adapter = new OracleDataAdapter(comd, Program.conn);
            ds = new DataSet();
            adapter.Fill(ds);

            description.Text = ds.Tables[0].Rows[0]["DESCRIPTION"].ToString();
            decision.Text = ds.Tables[0].Rows[0]["DECISION"].ToString();
            defendant.Text = ds.Tables[0].Rows[0]["DEFENDANT_ID"].ToString();
            status.Text = ds.Tables[0].Rows[0]["STATUS"].ToString();
            if (status.Text == "new") {
                refuse.Enabled = true;
                accept.Enabled = true;
            }
            if (status.Text == "closed")
            {
                remove.Enabled = true;
            }
            requestDate.Text = ds.Tables[0].Rows[0]["REQUEST_DATE"].ToString();
            startDate.Text = ds.Tables[0].Rows[0]["START_DATE"].ToString();
            caseDate.Text = ds.Tables[0].Rows[0]["CASE_DATE"].ToString();
            endDate.Text = ds.Tables[0].Rows[0]["END_DATE"].ToString();
            place.Text = ds.Tables[0].Rows[0]["PLACE"].ToString();
            lawyer.Text = User.User.get_user_name(ds.Tables[0].Rows[0]["LAWYER_ID"].ToString());
            defendant.Text = User.User.get_user_name(ds.Tables[0].Rows[0]["DEFENDANT_ID"].ToString());

            OracleCommand cmd1 = new OracleCommand();
            cmd1.Connection = Program.conn;
            cmd1.CommandType = CommandType.Text;
            cmd1.CommandText = "select FILENAME from CASE_DOCUMENTS where CASE_ID = " + Case_id;
            OracleDataReader dr = cmd1.ExecuteReader();
            while (dr.Read())
            {
                docComboBox.Items.Add(dr[0]);
            }
            cmd1.CommandText = "select JUDGE_ID from CASE_JUDGES where CASE_ID = " + Case_id;
            dr = cmd1.ExecuteReader();
            while (dr.Read())
            {
                string id =dr[0].ToString();
                judgesList.Items.Add(User.User.get_user_name(id));
            }

           
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //exit
            Application.Exit();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            //back
            new H_Home().Show();
            this.Close();

        }

    
   

    

        private void refuse_Click(object sender, EventArgs e)
        {
            //refuse
            OracleCommand cmd1 = new OracleCommand();
            cmd1.Connection = Program.conn;
            cmd1.CommandText = "delete from CASES where CASE_ID = " + Case_id;
            int r = cmd1.ExecuteNonQuery();
            if (r != -1)
            {
                MessageBox.Show("Done");
                new H_Home().Show();
                this.Close();

            }
        }

        private void accept_Click(object sender, EventArgs e)
        {
            //accept
            new Acceptance_Form(Case_id , ds, adapter).ShowDialog();
            new H_Case(Case_id).Show();
            this.Close();
        }

        private void savePdf_Click(object sender, EventArgs e)
        {
            //open pdf
            string fileName = Convert.ToString(docComboBox.Text.ToString());
            if (fileName == "") return;
            OracleCommand cmd1 = new OracleCommand();
            cmd1.Connection = Program.conn;
            cmd1.CommandText = "select FILEDATA from CASE_DOCUMENTS where FILENAME = :fileName";
            cmd1.Parameters.Add("fileName", fileName);
            OracleDataReader reader = cmd1.ExecuteReader();
            if (!reader.Read())
            {
                MessageBox.Show("Click save first");
                return;
            }
            byte[] buffer = new byte[reader.GetBytes(0, 0, null, 0, int.MaxValue)];
            reader.GetBytes(0, 0, buffer, 0, buffer.Length);
            try
            {
                SaveFileDialog saveFileDialog = new SaveFileDialog();
                saveFileDialog.Filter = "|*.pdf";
                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string filePath = saveFileDialog.FileName;
                    File.WriteAllBytes(filePath, buffer);
                    Process.Start(filePath);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OracleCommand cmd1 = new OracleCommand();
            cmd1.Connection = Program.conn;
            cmd1.CommandText = "delete from CASES where CASE_ID = " + Case_id;
            int r = cmd1.ExecuteNonQuery();
            if (r != -1)
            {
                MessageBox.Show("Done");
                new H_Home().Show();
                this.Close();
            }
        }
    }
}
