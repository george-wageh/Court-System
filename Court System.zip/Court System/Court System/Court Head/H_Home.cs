﻿using Court_System.Lawyer;
using Court_System.User;
using Oracle.DataAccess.Client;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Court_System.Court_Head
{
    public partial class H_Home : Form
    {
        public H_Home()
        {
            this.StartPosition = FormStartPosition.CenterScreen;

            InitializeComponent();
        }
        private string getStatus()
        {

            if (newR.Checked)
            {
                return "new";
            }
            else if (opendR.Checked)
            {
                return "opened";
            }
            else if (closedR.Checked)
            {
                return "closed";
            }
            else if (adjournR.Checked)
            {
                return "adjournment";
            }
            else if (appealR.Checked)
            {
                return "appeal";
            }
            else return "";
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.RowIndex < casesDataGrid.Rows.Count)
            {
                string CASE_ID = casesDataGrid.Rows[e.RowIndex].Cells[0].Value.ToString();
                new H_Case(CASE_ID).Show();
                this.Close();
            }
        }
        private void fillDataGrid() {
            OracleCommand command = new OracleCommand();
            command.Connection = Program.conn;
            command.CommandType = CommandType.StoredProcedure;
            command.CommandText = "get_allCases";
            command.Parameters.Add("status", getStatus());
            command.Parameters.Add("cases", OracleDbType.RefCursor, ParameterDirection.Output);
            OracleDataAdapter adapter = new OracleDataAdapter(command);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            casesDataGrid.DataSource = dt;

        }

        private void H_Home_Load(object sender, EventArgs e)
        {
            fillDataGrid();

            Rectangle screen = Screen.PrimaryScreen.WorkingArea;
            int x = (screen.Width - this.Width) / 2;
            int y = (screen.Height - this.Height) / 2;
            this.Location = new Point(x, y);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Program.user = null;
            new LoginForm().Show();
            this.Close();
        }

        private void newR_CheckedChanged(object sender, EventArgs e)
        {
            fillDataGrid();

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            //Search
            foreach (DataGridViewRow row in casesDataGrid.Rows)
            {
                row.Selected = false;
            }
            string searchValue = textBox1.Text.Trim().ToLower();

            foreach (DataGridViewRow row in casesDataGrid.Rows)
            {
                foreach (DataGridViewCell cell in row.Cells)
                {
                    if (cell.Value != null && cell.Value.ToString().ToLower().Contains(searchValue))
                    {
                        row.Selected = true;
                        casesDataGrid.FirstDisplayedScrollingRowIndex = row.Index;
                        break;
                    }
                }
            }
        }

       
        private void button1_Click_1(object sender, EventArgs e)
        {
            new RemoveJudge().ShowDialog();
        }
    }
}
