﻿using System;

namespace Court_System.Court_Head
{
    partial class Acceptance_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.judgesList = new System.Windows.Forms.ListBox();
            this.judges = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.judgeName = new System.Windows.Forms.TextBox();
            this.button10 = new System.Windows.Forms.Button();
            this.allJudes = new System.Windows.Forms.ComboBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label17 = new System.Windows.Forms.Label();
            this.place = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.save = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // judgesList
            // 
            this.judgesList.ForeColor = System.Drawing.Color.Black;
            this.judgesList.FormattingEnabled = true;
            this.judgesList.Location = new System.Drawing.Point(81, 41);
            this.judgesList.Name = "judgesList";
            this.judgesList.Size = new System.Drawing.Size(100, 82);
            this.judgesList.TabIndex = 224;
            // 
            // judges
            // 
            this.judges.AutoSize = true;
            this.judges.ForeColor = System.Drawing.Color.Black;
            this.judges.Location = new System.Drawing.Point(63, 16);
            this.judges.Name = "judges";
            this.judges.Size = new System.Drawing.Size(44, 13);
            this.judges.TabIndex = 223;
            this.judges.Text = "Judges:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(222, 74);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(35, 13);
            this.label11.TabIndex = 222;
            this.label11.Text = "Name";
            // 
            // judgeName
            // 
            this.judgeName.Location = new System.Drawing.Point(263, 72);
            this.judgeName.Name = "judgeName";
            this.judgeName.ReadOnly = true;
            this.judgeName.Size = new System.Drawing.Size(91, 20);
            this.judgeName.TabIndex = 221;
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(234, 119);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(114, 23);
            this.button10.TabIndex = 219;
            this.button10.Text = "Assign a judge";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // allJudes
            // 
            this.allJudes.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.allJudes.FormattingEnabled = true;
            this.allJudes.Location = new System.Drawing.Point(222, 44);
            this.allJudes.Name = "allJudes";
            this.allJudes.Size = new System.Drawing.Size(132, 21);
            this.allJudes.TabIndex = 220;
            this.allJudes.SelectedIndexChanged += new System.EventHandler(this.allJudes_SelectedIndexChanged);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(445, 74);
            this.dateTimePicker1.MinDate = new System.DateTime(2023, 4, 21, 0, 10, 48, 844);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(134, 20);
            this.dateTimePicker1.TabIndex = 240;
            this.dateTimePicker1.MinDate = DateTime.Now.AddDays(1);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.ForeColor = System.Drawing.Color.Black;
            this.label17.Location = new System.Drawing.Point(429, 49);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(60, 13);
            this.label17.TabIndex = 238;
            this.label17.Text = "Case Date:";
            // 
            // place
            // 
            this.place.ForeColor = System.Drawing.Color.Black;
            this.place.Location = new System.Drawing.Point(643, 103);
            this.place.Name = "place";
            this.place.Size = new System.Drawing.Size(100, 20);
            this.place.TabIndex = 242;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(623, 77);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(37, 13);
            this.label1.TabIndex = 241;
            this.label1.Text = "Place:";
            // 
            // save
            // 
            this.save.Location = new System.Drawing.Point(345, 199);
            this.save.Name = "save";
            this.save.Size = new System.Drawing.Size(115, 33);
            this.save.TabIndex = 243;
            this.save.Text = "Save";
            this.save.UseVisualStyleBackColor = true;
            this.save.Click += new System.EventHandler(this.save_Click);
            // 
            // Acceptance_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.save);
            this.Controls.Add(this.place);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.judgesList);
            this.Controls.Add(this.judges);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.judgeName);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.allJudes);
            this.Name = "Acceptance_Form";
            this.Text = "Acceptance form";
            this.Load += new System.EventHandler(this.Acceptance_Form_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox judgesList;
        private System.Windows.Forms.Label judges;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox judgeName;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.ComboBox allJudes;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox place;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button save;
    }
}