﻿using Oracle.DataAccess.Client;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Court_System.Court_Head
{
    public partial class RemoveJudge : Form
    {
        public RemoveJudge()
        {
            InitializeComponent();
        }

        private void RemoveJudge_Load(object sender, EventArgs e)
        {
            OracleCommand cmd = new OracleCommand();
            cmd.Connection = Program.conn;
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select user_id from users where user_type = :defe";
            cmd.Parameters.Add("defe", "judge");
            OracleDataReader dr0 = cmd.ExecuteReader();
            while (dr0.Read())
            {
                allJudes.Items.Add(dr0[0].ToString());
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            //Drop judge
            if(allJudes.Text == "")return;
            OracleCommand cmd = new OracleCommand();
            cmd.Connection = Program.conn;
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "DELETE from users where user_id = :defe";
            cmd.Parameters.Add("defe", allJudes.Text.ToString());
            int dr0 = cmd.ExecuteNonQuery();
            if (dr0 != -1)
            {
                allJudes.Items.Remove(allJudes.Text.ToString());
                judgeName.Text = "";
                MessageBox.Show("Done");
            }

        }

        private void allJudes_SelectedIndexChanged(object sender, EventArgs e)
        {
            judgeName.Text = User.User.get_user_name(allJudes.Text.ToString());

        }
    }
}
